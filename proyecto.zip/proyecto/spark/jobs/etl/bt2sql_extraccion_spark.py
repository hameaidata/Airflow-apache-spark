"""
bt2sql_extraccion_spark - Bantotal (IBM i) -> Parquet, con Spark.

GEMELO DEL PIPELINE DE PANDAS, NO SU REEMPLAZO
----------------------------------------------
Hace lo mismo que etl_bt2sql/bt2sql_extraccion.py: lee el catalogo, consulta
Bantotal tabla por tabla y escribe un parquet por tabla, dejando el rastro en
ctl_proceso_parquet. Lo que cambia es QUIEN lee: aqui el origen se lee con
varios hilos en paralelo, uno por rango de la columna de particion.

El pipeline de pandas NO se toca. Los dos pueden convivir y producir el mismo
dia para compararse, porque escriben en carpetas distintas y se registran en la
bitacora con nom_proceso distinto.

DONDE GANA SPARK, Y DONDE NO
----------------------------
Gana en la LECTURA del core: spark.read.jdbc con partitionColumn abre N
conexiones y cada una trae un rango de filas. Contra una tabla historica de
decenas de millones, eso es la diferencia entre horas y minutos.

NO gana en nada mas. El catalogo y la bitacora se leen y escriben desde el
DRIVER con JDBC crudo, en un solo hilo, porque son decenas de filas. Y si la
tabla no declara particion, la lectura cae a UNA sola conexion: Spark hace
entonces el mismo trabajo que pandas pero con la latencia de un cluster. Por
eso el job AVISA cuando eso ocurre, en vez de dejarlo pasar en silencio.

LOS TIPOS SALEN DEL CATALOGO
----------------------------
La columna TIPOS de CTL_PARAMETROS_PARQUET manda sobre el esquema del parquet,
igual que en el pipeline de pandas. Sin eso, Spark infiere del JDBC y una
columna DECIMAL sin escala acaba como texto, o peor: el primer bloque la ve
toda NULL y el esquema queda inservible para los siguientes.

INVOCACION  -- la hace el DAG, no se ejecuta a mano
    spark-submit /opt/spark-apps/etl/bt2sql_extraccion_spark.py \
        --jdbc-url <url de Bantotal>  --driver-class com.ibm.as400.access.AS400JDBCDriver \
        --config /opt/spark-data/runtime/bt2sql_spark.json \
        --batch-id 20261005120000 --tipo-ejecucion diario
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import re
import sys
from datetime import date, datetime, timedelta

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("bt2sql_extraccion_spark")

IDENTIFICADOR = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# 'bucket' es una expresion SQL del catalogo, no un identificador: hay que
# permitir parentesis y aritmetica ("PGFCIE / 100", "YEAR(F_ALTA)") pero cerrar
# la puerta a comillas, punto y coma y comentarios, que es por donde se cuela
# una inyeccion desde una Variable de Airflow.
# El lookahead no es decorativo: "-" y "/" tienen que estar permitidos
# (fechas, division) y eso deja pasar "--", "/*" y "*/", con los que se
# comenta el resto de la consulta. Lo encontro un test, no una revision.
EXPRESION_BUCKET = re.compile(
    r"^(?!.*(--|/\*|\*/))[A-Za-z0-9_()\s/*+.,:-]{1,120}$")
# ============================================================================
# CONEXIONES CRUDAS DESDE EL DRIVER
# ----------------------------------------------------------------------------
# El catalogo y la bitacora viven en SQL Server y son decenas de filas. Leerlas
# con spark.read.jdbc costaria mas en coordinacion que lo que tardan. Se abren
# desde la JVM del driver, igual que hace ejecutar_sp_spark.py.
# ============================================================================



def abrir_jdbc(spark, url: str, usuario: str, clave: str, clase: str):
    jvm = spark._jvm
    jvm.Class.forName(clase)
    props = jvm.java.util.Properties()
    props.setProperty("user", usuario or "")
    props.setProperty("password", clave or "")
    return jvm.java.sql.DriverManager.getConnection(url, props)


def filas_de(conexion, sql: str) -> list[dict]:
    """Ejecuta un SELECT y devuelve lista de dicts. Para consultas pequenas."""
    st = conexion.createStatement()
    try:
        rs = st.executeQuery(sql)
        meta = rs.getMetaData()
        n = meta.getColumnCount()
        nombres = [meta.getColumnLabel(i + 1) for i in range(n)]
        salida = []
        while rs.next():
            salida.append({nombres[i]: rs.getObject(i + 1) for i in range(n)})
        rs.close()
        return salida
    finally:
        st.close()


def ejecutar(conexion, sql: str, parametros: tuple = ()) -> None:
    ps = conexion.prepareStatement(sql)
    try:
        for i, v in enumerate(parametros, start=1):
            ps.setObject(i, v)
        ps.execute()
    finally:
        ps.close()


# ============================================================================
# TIPOS DEL CATALOGO  (mismo contrato que el pipeline de pandas)
# ============================================================================
def parsear_tipos(tipos_str, tabla: str = "") -> dict[str, dict]:
    """COLUMNA:TIPO|COLUMNA:TIPO  ->  {columna: {type, precision, scale}}."""
    mapa: dict[str, dict] = {}
    if not tipos_str or not str(tipos_str).strip():
        return mapa
    for item in str(tipos_str).split("|"):
        item = item.strip()
        if not item:
            continue
        if ":" not in item:
            raise SystemExit(
                f"[{tabla}] TIPOS mal formado: {item!r}. "
                f"El formato es COLUMNA:TIPO separado por |")
        col, tipo = item.split(":", 1)
        col, tipo = col.strip(), tipo.strip().lower()
        if tipo.startswith(("char", "varchar", "nchar", "nvarchar")):
            mapa[col] = {"type": "string"}
        elif tipo.startswith(("decimal", "numeric")):
            m = re.search(r"\((\d+)\s*,\s*(\d+)\)", tipo)
            if not m:
                raise SystemExit(f"[{tabla}] DECIMAL sin precision: {item!r}")
            mapa[col] = {"type": "decimal",
                         "precision": int(m.group(1)), "scale": int(m.group(2))}
        elif tipo in ("int", "integer", "smallint"):
            mapa[col] = {"type": "int"}
        elif tipo == "bigint":
            mapa[col] = {"type": "bigint"}
        elif tipo in ("float", "double", "real"):
            mapa[col] = {"type": "float"}
        elif tipo == "date":
            mapa[col] = {"type": "date"}
        elif tipo.startswith(("datetime", "timestamp", "smalldatetime")):
            mapa[col] = {"type": "timestamp"}
        elif tipo == "bit":
            # Se trata como entero y no como booleano: en el core un indicador
            # viene como 0/1 numerico, y un BooleanType en el parquet obliga a
            # convertir otra vez al escribir en un BIT de SQL Server.
            mapa[col] = {"type": "int"}
        else:
            logger.warning("[%s] tipo no reconocido %r en %r: se trata como texto",
                           tabla, tipo, col)
            mapa[col] = {"type": "string"}
    return mapa


# SQL Server -> el mismo diccionario que devuelve parsear_tipos
SQLSERVER_A_TIPO = {
    "decimal": "decimal", "numeric": "decimal", "money": "decimal",
    "smallmoney": "decimal",
    "int": "int", "integer": "int", "smallint": "int", "tinyint": "int",
    "bit": "int",
    "bigint": "bigint",
    "float": "float", "real": "float",
    "char": "string", "varchar": "string", "nchar": "string",
    "nvarchar": "string", "text": "string", "ntext": "string",
    "uniqueidentifier": "string",
    "date": "date",
    "datetime": "timestamp", "datetime2": "timestamp",
    "smalldatetime": "timestamp", "datetimeoffset": "timestamp",
}

# Las inyecta la extraccion, no vienen del core: no se leen del destino.
COLUMNAS_INYECTADAS = {"FECHA_PROCESO", "BATCH_ID"}


def tipos_de_destino(conn_ctl, tabla_destino: str, tabla: str) -> dict[str, dict]:
    """Deduce los tipos leyendo la TABLA DESTINO de SQL Server.

    POR QUE ESTA ES LA MEJOR FUENTE DE TIPOS
    ----------------------------------------
    El objetivo del cast no es estetico: es que el parquet tenga exactamente
    los tipos que la tabla destino espera, porque si no coinciden el INSERT por
    JDBC falla -o, peor, no falla y trunca-. Y quien sabe con certeza esos
    tipos no es la Variable ni el catalogo: es la propia tabla destino.

    Asi que el orden de preferencia es:

        1. tablas[].tipos de la Variable, si esta declarado. Es el override
           explicito y gana siempre: sirve para los casos en que el destino
           tiene un tipo mas ancho a proposito.
        2. INFORMATION_SCHEMA.COLUMNS de la tabla destino. No hay que
           mantenerlo a mano y no se desincroniza nunca, porque ES el destino.
        3. Lo que el driver JDBC infiera del core. Ultimo recurso.

    Si la tabla destino no existe, se avisa y se cae al paso 3 en vez de
    fallar: el error de "tabla destino inexistente" tiene que salir de la
    carga, que es quien lo puede explicar bien, no de aqui.
    """
    partes = str(tabla_destino).replace("[", "").replace("]", "").split(".")
    esquema, nombre = ("dbo", partes[0]) if len(partes) == 1 else (partes[0], partes[1])

    filas = filas_de(conn_ctl,
        "SELECT COLUMN_NAME, DATA_TYPE, NUMERIC_PRECISION, NUMERIC_SCALE "
        "FROM INFORMATION_SCHEMA.COLUMNS "
        f"WHERE TABLE_SCHEMA = '{validar(esquema, 'esquema destino')}' "
        f"  AND TABLE_NAME = '{validar(nombre, 'tabla destino')}'")
    if not filas:
        logger.warning(
            "[%s] la tabla destino %s no existe o no tiene columnas visibles: "
            "no se pueden deducir tipos de ahi. Se usara lo que infiera el "
            "driver JDBC, que es justo lo que suele romper la escritura.",
            tabla, tabla_destino)
        return {}

    mapa: dict[str, dict] = {}
    desconocidos = []
    for f in filas:
        col = str(f["COLUMN_NAME"])
        if col.upper() in COLUMNAS_INYECTADAS:
            continue
        sql_tipo = str(f["DATA_TYPE"]).strip().lower()
        tipo = SQLSERVER_A_TIPO.get(sql_tipo)
        if tipo is None:
            desconocidos.append(f"{col}:{sql_tipo}")
            continue
        if tipo == "decimal":
            mapa[col] = {"type": "decimal",
                         "precision": int(f["NUMERIC_PRECISION"] or 38),
                         "scale": int(f["NUMERIC_SCALE"] or 0)}
        else:
            mapa[col] = {"type": tipo}

    if desconocidos:
        logger.warning("[%s] tipos de %s que no se saben traducir, se dejan "
                       "como vengan: %s", tabla, tabla_destino,
                       ", ".join(desconocidos))
    logger.info("[%s] tipos deducidos de la tabla destino %s: %s columna(s)",
                tabla, tabla_destino, len(mapa))
    return mapa


def aplicar_tipos(df, mapa: dict[str, dict], tabla: str):
    """Castea las columnas declaradas. La cadena vacia pasa a NULL ANTES del
    cast: '' casteado a decimal da NULL en Spark, pero a int da 0 en algunas
    versiones, y un cero inventado en un importe es peor que un nulo."""
    equivalencias = {
        "int": T.IntegerType(),
        "bigint": T.LongType(),
        "float": T.DoubleType(),
        "string": T.StringType(),
        "date": T.DateType(),
        "timestamp": T.TimestampType(),
    }
    presentes = set(df.columns)
    for col, cfg in mapa.items():
        if col not in presentes:
            logger.warning("[%s] TIPOS declara %r y no viene en el SELECT: se ignora",
                           tabla, col)
            continue
        if cfg["type"] == "decimal":
            destino = T.DecimalType(cfg["precision"], cfg["scale"])
        else:
            destino = equivalencias[cfg["type"]]

        if cfg["type"] in ("int", "bigint", "float", "decimal", "date", "timestamp"):
            df = df.withColumn(col, F.when(F.trim(F.col(col).cast("string")) == "", None)
                                     .otherwise(F.col(col)))
        df = df.withColumn(col, F.col(col).cast(destino))
    return df


# ============================================================================
# LECTURA DEL ORIGEN
# ============================================================================
def validar(valor, campo: str) -> str:
    v = str(valor or "").strip()
    if not IDENTIFICADOR.match(v):
        raise SystemExit(f"{campo} no es un identificador valido: {valor!r}")
    return v


# ---------------------------------------------------------------------------
# LAS MARCAS DEL FILTRO
# ---------------------------------------------------------------------------
# FILTRO es el WHERE de cada tabla, y hasta ahora se concatenaba TAL CUAL. Eso
# obliga a escribir la fecha a mano y a editar el catalogo cada dia, que es la
# forma mas segura de que un dia se olvide y la extraccion traiga el dia
# equivocado sin que nada falle.
#
# Con las marcas, el filtro se escribe UNA vez y la fecha la pone el job, con
# el mismo valor que ya leyo de GPPPBTDB.FST017 (el campo PGFCIE). Es la misma
# fecha que va a FECHA_PROCESO y a la subcarpeta del dia, asi que las tres
# cosas no pueden desalinearse.
#
#     FILTRO = "FSH005FEC = {FECHA_AAAAMMDD}"
#       ->    WHERE FSH005FEC = 20261010
#
# LAS MARCAS
#   {FECHA_AAAAMMDD}  20261010      sin comillas. Para las columnas de fecha
#                                   de Bantotal, que son DECIMAL(8,0)
#   {FECHA_ISO}       '2026-10-10'  CON comillas. Para columnas DATE de verdad
#   {FECHA_AAAAMM}    202610        tablas mensuales
#   {FECHA_AAAA}      2026          tablas anuales
#   {BATCH_ID}        '2026...'     CON comillas. Trazabilidad
#
# Las de fecha admiten un desplazamiento en DIAS, para ventanas:
#
#     FILTRO = "FSH005FEC BETWEEN {FECHA_AAAAMMDD-6} AND {FECHA_AAAAMMDD}"
#       ->    WHERE FSH005FEC BETWEEN 20261004 AND 20261010
#
# UNA MARCA DESCONOCIDA ES UN ERROR, NO SE DEJA PASAR
# ---------------------------------------------------
# Si se escribe {FECHA} o {FECHA_PROCESO} -que no existen- el job FALLA
# diciendo cuales hay. Dejarla pasar literal seria peor que fallar: contra
# SQL Server da un error de sintaxis oscuro, y contra DB2 for i hay sintaxis
# donde una llave no revienta y el WHERE acaba significando otra cosa.
#
# ESTO NO SANEA EL FILTRO
# -----------------------
# FILTRO sigue siendo SQL libre concatenado, con todo lo que eso implica:
# quien pueda editar esa columna puede consultar cualquier cosa del origen.
# Lo unico que anaden las marcas son valores que calcula el propio job -una
# fecha y un batch_id-, no una validacion de lo que el humano escribio.
#
# ESTA FUNCION ESTA DUPLICADA en el pipeline de pandas
# (airflow/dags/production/etl_bt2sql/bt2sql_extraccion.py). Hay un test que
# compara las dos salidas y falla si divergen: mismo criterio que la lista de
# drivers JDBC de los dos Dockerfile. Duplicar esta bien mientras no pueda
# pasar en silencio.
MARCAS_FILTRO = re.compile(r"\{([A-Z][A-Z0-9_]*)(?:\s*([+-])\s*(\d{1,4}))?\}")

# Lo que PARECE una marca y no se sustituyo. No vale con buscar "{" a secas:
# JDBC y ODBC tienen literales de fecha con llaves -{d '2026-01-01'}- que son
# SQL legitimo, y este patron no los toca porque llevan comilla y espacio.
RESTO_DE_MARCA = re.compile(r"\{[A-Za-z_][A-Za-z0-9_]*(?:\s*[+-]\s*\d+)?\}")

# El batch_id acaba DENTRO de una cadena SQL, asi que se comprueba antes.
# Hoy lo genera preparar_config y son 14 digitos, pero el job se puede invocar
# a mano con --batch-id, y esa es la puerta por la que entraria una comilla.
BATCH_SEGURO = re.compile(r"^[A-Za-z0-9_]{1,32}$")

MARCAS_VALIDAS = ("FECHA_AAAAMMDD", "FECHA_ISO", "FECHA_AAAAMM",
                  "FECHA_AAAA", "BATCH_ID")


def sustituir_marcas(filtro: str, tabla: str, fecha_proceso=None,
                     batch_id: str | None = None) -> str:
    """Resuelve las marcas de un FILTRO. Sin marcas, lo devuelve intacto."""
    if not filtro or "{" not in filtro:
        return filtro

    def una(m) -> str:
        nombre, signo, cantidad = m.group(1), m.group(2), m.group(3)

        if nombre not in MARCAS_VALIDAS:
            raise SystemExit(
                f"[{tabla}] FILTRO usa una marca que no existe: "
                f"{{{nombre}}}.\nLas que hay son: "
                + ", ".join("{" + x + "}" for x in MARCAS_VALIDAS)
                + "\nLas de fecha admiten un desplazamiento en dias, "
                  "por ejemplo {FECHA_AAAAMMDD-6}.")

        if nombre == "BATCH_ID":
            if signo:
                raise SystemExit(
                    f"[{tabla}] FILTRO aplica un desplazamiento a "
                    f"{{BATCH_ID}}, y un batch_id no es una fecha.")
            if batch_id is None:
                raise SystemExit(
                    f"[{tabla}] FILTRO usa {{BATCH_ID}} pero esta extraccion "
                    f"no recibio batch_id.")
            if not BATCH_SEGURO.match(str(batch_id)):
                raise SystemExit(
                    f"[{tabla}] el batch_id {batch_id!r} tiene caracteres que "
                    f"no se admiten dentro de un FILTRO. Solo letras, digitos "
                    f"y _, hasta 32.")
            return f"'{batch_id}'"

        if fecha_proceso is None:
            raise SystemExit(
                f"[{tabla}] FILTRO usa {{{nombre}}} pero esta extraccion no "
                f"recibio la fecha de proceso. La lee sql_fecha de la "
                f"Variable, de GPPPBTDB.FST017.")

        dias = int(cantidad or 0) * (-1 if signo == "-" else 1)
        f = fecha_proceso + timedelta(days=dias)

        if nombre == "FECHA_AAAAMMDD":
            return f"{f:%Y%m%d}"
        if nombre == "FECHA_ISO":
            return f"'{f:%Y-%m-%d}'"
        if nombre == "FECHA_AAAAMM":
            return f"{f:%Y%m}"
        return f"{f:%Y}"                                  # FECHA_AAAA

    resuelto = MARCAS_FILTRO.sub(una, filtro)

    sobra = RESTO_DE_MARCA.search(resuelto)
    if sobra:
        raise SystemExit(
            f"[{tabla}] FILTRO deja sin resolver {sobra.group(0)}. Las marcas "
            f"van en MAYUSCULAS y sin espacios dentro de las llaves. "
            f"Las que hay son: "
            + ", ".join("{" + x + "}" for x in MARCAS_VALIDAS))
    return resuelto


from datetime import timedelta
import re

CONFIG_PARTICIONES = {
    "FSH0167": {
        "columna": "BCFECH_PART",
        "dias_atras": 30,
        "particiones": 8
    }
}


def contruccion_filtros_casos_especificos(fila, fecha_proceso): ## CASO A REVISAR CUANDO EXISTE PARTICIONES DE FECHA
    tabla = str(fila.get("TABLA", "")).upper()
    cfg = CONFIG_PARTICIONES.get(tabla)
    if not cfg:
        return fila
    fecha_fin = fecha_proceso.strftime("%Y%m%d")
    fecha_inicio = (
        fecha_proceso - timedelta(days=cfg["dias_atras"])
    ).strftime("%Y%m%d")
    filtro = str(fila.get("FILTRO") or "")
    filtro = (
        filtro
        .replace("{FECHA_INICIO}", fecha_inicio)
        .replace("{FECHA_FIN}", fecha_fin)
    )
    fila["FILTRO"] = filtro
    logger.info("*" * 100)
    logger.info(f"Mostrando el filtro:\n{filtro}")
    # CASOS ESPECIALES CON PREDICATES
    if tabla == "FSH012":
        fecha_ini_dt = fecha_proceso - timedelta(days=cfg["dias_atras"])
        fecha_fin_dt = fecha_proceso
        total_dias = (
            fecha_fin_dt - fecha_ini_dt
        ).days + 1
        dias_por_particion = max(
            1,
            total_dias // cfg["particiones"]
        )
        predicates = []
        ini = fecha_ini_dt
        while ini <= fecha_fin_dt:
            fin = min(
                ini + timedelta(days=dias_por_particion - 1),
                fecha_fin_dt
            )
            predicates.append(
                f"BCFECH >= '{ini.strftime('%Y%m%d')}' "
                f"AND BCFECH <= '{fin.strftime('%Y%m%d')}'"
            )
            ini = fin + timedelta(days=1)
        fila["_PREDICATES"] = predicates
        logger.info(
            "[%s] Predicates generados: %s",
            tabla,
            len(predicates)
        )
        for p in predicates:
            logger.info(p)
    return fila

def construir_select(fila: dict, fecha_proceso=None,
                     batch_id: str | None = None) -> str:


    logger.info("="*10)
    logger.info(fila)
    logger.info("="*10)
    esquema = validar(fila["ESQUEMA"], "ESQUEMA")
    tabla = validar(fila["TABLA"], "TABLA")

    columnas = (str(fila.get("COLUMNAS") or "*")).strip() or "*"
    # MODIFICAR PORQUE SON CARACTERITICAS ESPECIFICAS DE CADA TABLA
    # ==============================================================
    if tabla =='FSH012':
        sql =  f"SELECT {columnas}, CAST(BCFECH AS BIGINT) AS BCFECH_PART  FROM {esquema}.{tabla}"
        
    else:
        sql = f"SELECT {columnas} FROM {esquema}.{tabla}"
    # ==============================================================
    filtro = (str(fila.get("FILTRO") or "")).strip()
    if filtro:
        sql += f" WHERE {sustituir_marcas(filtro, tabla, fecha_proceso, batch_id)}"

    logger.info("Mostrando la consulta sql server")
    logger.info(sql)
    logger.info("="*100)
    return sql


def leer_origen(spark, url: str, clase: str, usuario: str, clave: str,
                fila: dict, particion: dict | None, fetchsize: int,
                fecha_proceso=None, batch_id: str | None = None):
    """Lee la tabla del core. Con particion, en paralelo; sin ella, en un hilo.

    El aviso cuando falta la particion no es decorativo: sin ella este job hace
    exactamente el trabajo del pipeline de pandas pero arrastrando un cluster,
    y conviene que eso se vea en el log en vez de descubrirlo comparando
    tiempos semana tras semana.
    """
    fila = contruccion_filtros_casos_especificos(
        fila,
        fecha_proceso
    )

    if particion is None:
        particion = fila.get("_PARTICION")

    tabla = fila["TABLA"]

    select = construir_select(fila, fecha_proceso, batch_id)
    consulta = f"({select}) AS q"

    # El SELECT resuelto, en el log. El pipeline de pandas ya lo hacia y este
    # no: con FILTRO literal se podia deducir del catalogo, pero con las
    # marcas el WHERE que de verdad se manda ya no esta escrito en ningun
    # sitio, y sin esta linea no habria forma de comprobar que la fecha
    # sustituida es la que se esperaba.
    logger.info("   SQL : %s", select)

    lector = (spark.read.format("jdbc")
              .option("url", url)
              .option("driver", clase)
              .option("user", usuario)
              .option("password", clave)
              .option("dbtable", consulta)
              .option("fetchsize", int(fetchsize)))
              

    if particion:
        logger.info("="*100)
        logger.info(f"Particion de generada: {particion}")
        col = validar(particion["columna"], "particion.columna")
        lector = (lector
                  .option("partitionColumn", col)
                  .option("lowerBound", str(particion["desde"]))
                  .option("upperBound", str(particion["hasta"]))
                  .option("numPartitions", str(particion["particiones"])))
        logger.info("[%s] lectura en %s particiones por %s [%s..%s]",
                    tabla, particion["particiones"], col,
                    particion["desde"], particion["hasta"])
    else:
        logger.warning(
            "[%s] SIN particion declarada: se lee con UNA sola conexion. "
            "Spark no aporta paralelismo aqui. Declare la tabla en "
            "'particiones' de la Variable para que lea en varios hilos.", tabla)

    return lector.load()


# ============================================================================
# BITACORA  (ctl_proceso_parquet, en SQL Server)
# ============================================================================
def filtrar_por_procesos(filas: list[dict], cfg: dict, tipo_ejecucion: str) -> list[dict]:
    """Aplica la lista 'procesos' y ORDENA por prioridad.

    ESTO FALTABA, Y ERA UN FALLO DE VERDAD
    --------------------------------------
    Hasta el 2026-10-07 este job extraia todas las tablas con activo='S' y en el
    orden en que estuvieran escritas en la Variable: ignoraba 'procesos' por
    completo. El resultado era que una tabla con estado=0, o con el flag del
    calendario del dia en 0, se extraia igual. El DAG la reportaba como
    'inactiva' en el inventario y Spark la extraia a continuacion.

    Eso no es solo un dia de datos de mas: rompe la unica validacion que dice
    que la traduccion a Spark salio bien, que es correr los dos pipelines sobre
    el mismo dia y comparar fila a fila. El de pandas si filtra.

    La semantica se copia de filtrar_procesos() de etl_bt2sql/bt2sql_extraccion.py
    para que las dos mitades decidan igual:

      - el cruce es (nombre_proceso, nombre_esquema) contra
        (NOMBRE_PARQUET o TABLA, ESQUEMA), todo en mayusculas
      - el proceso tiene que traer estado=1 Y el flag del dia en 1
      - prioridad ordena; sin prioridad declarada, 99, o sea al final
    """


    flag = {"diario": "estado_diario",
            "semanal": "estado_semanal",
            "mensual": "estado_mensual"}.get(tipo_ejecucion)
    if flag is None:
        raise SystemExit(
            f"tipo_ejecucion={tipo_ejecucion!r} no soportado. "
            f"Use diario, semanal o mensual.")

    declarados = cfg.get("procesos") or []
    if not declarados:
        raise SystemExit(
            "La configuracion no trae 'extraccion.procesos', asi que no hay "
            "calendario que aplicar. Declarelo en la Variable: una tabla entra "
            "en una corrida solo si esta en 'tablas' con activo='S' Y en "
            "'procesos' con estado=1 y el flag del dia en 1.")

    activos, inactivos = {}, []
    for p in declarados:

        clave = (str(p.get("nombre_proceso", "")).strip().upper(),
                 str(p.get("nombre_esquema", "")).strip().upper())

        logger.info(f"clave: {clave}")
        if int(p.get("estado", 0)) == 1 and int(p.get(flag, 0)) == 1:
            activos[clave] = p
        else:
            motivo = ("estado=0" if int(p.get("estado", 0)) != 1
                      else f"{flag}=0")
            inactivos.append(f"{clave[0]} ({motivo})")

    seleccion, fuera = [], []
    for fila in filas:
        nombre = str(fila.get("NOMBRE_PARQUET") or fila["TABLA"]).strip().upper()
        clave = (nombre, str(fila["ESQUEMA"]).strip().upper())
        proc = activos.get(clave)
        if proc is None:
            fuera.append(f"{clave[1]}.{fila['TABLA']} (proceso {clave[0]})")
            continue
        seleccion.append({**fila, "_PRIORIDAD": int(proc.get("prioridad", 99))})

    logger.info("CALENDARIO tipo_ejecucion=%s (flag %s): %s de %s proceso(s) activos",
                tipo_ejecucion, flag, len(activos), len(declarados))
    if inactivos:
        logger.info("  procesos que no entran hoy: %s", ", ".join(inactivos))
    if fuera:
        logger.info("  tablas que no entran hoy   : %s", ", ".join(fuera))

    if not seleccion:
        raise SystemExit(
            f"Ninguna tabla declarada coincide con los procesos activos para "
            f"tipo_ejecucion={tipo_ejecucion!r}.\n"
            f"El cruce es tablas[].nombre_proceso + tablas[].esquema contra "
            f"procesos[].nombre_proceso + procesos[].nombre_esquema, y el "
            f"proceso necesita estado=1 y {flag}=1.")

    seleccion.sort(key=lambda f: (f["_PRIORIDAD"], str(f["TABLA"])))
    logger.info("ORDEN DE EXTRACCION por prioridad:")
    for f in seleccion:
        logger.info("  prioridad %-3s %s.%s", f["_PRIORIDAD"], f["ESQUEMA"], f["TABLA"])
    return seleccion


def _clave( esquema, tabla)->tuple[str, str]:
    return (str(esquema or "").strip().upper(), str(tabla or "").strip().upper())

def _es_activo(valor)->str:
    return  str(valor if  valor is not None else "S").strip().upper()=="S"


def catalogo_de_tablas(cfg: dict, conn_ctl, tipo_ejecucion: str = "diario") -> list[dict]:
    """Devuelve las tablas por extraer, de la Variable o del catalogo.

    Con origen_tablas='variable' (lo normal) la lista sale de la Variable de
    Airflow y NO se consulta CTL_PARAMETROS_PARQUET. La ventaja no es ahorrar
    una consulta: es que agregar una tabla pasa a ser editar un JSON versionado
    en el repositorio, revisable en un diff, en vez de un UPDATE a mano contra
    una tabla de produccion que nadie ve pasar.

    Se normalizan las claves A MAYUSCULAS en los dos casos para que el resto
    del job no tenga que saber de donde vino la lista.
    """
    crudas = filas_de(conn_ctl, cfg["sql_parametros_parquet"])

    if not crudas:
        raise SystemExit("CTL_PARAMETROS_PARQUET no devolvio ningun tabla")
    
    catalogo =  {}

    for cruda in  crudas:
        fila = {str(k).strip().upper(): ("" if v is None else v) for k,v in cruda.items()}
        catalogo [_clave(fila.get("ESQUEMA"),fila.get("TABLA"))]=fila
    declaradas = cfg.get("tablas") or []

    
    if not declaradas:
        raise SystemExist(
            "La Variable no trae  ningun tabla en 'tablas'. Agregalas en"
            "airflow/config/json/BT2SQL_SPARK.json y sincronice con"
            "python scripts/sync_variables.py --SOLO BT2SQL_SPARK"

        )
    variable = {_clave(e.get("esquema"), e.get("tabla")): e for e in declaradas}

    
    filas = []
    inactivas_catalogo, inactivas_variable  = [],[]
    solo_catalogo, solo_variable = [],[]

    
    for clave, fila in catalogo.items():
        nombre =".".join(clave)
        entrada = variable.get(clave)
        if entrada is None:
            solo_catalogo.append(nombre)
            continue
        if not _es_activo(fila.get("ACTIVO")):
            inactivas_catalogo.append(nombre)
            continue
        if not _es_activo(entrada.get("activo")):
            inactivas_variable.append(nombre)
            continue

        fila["NOMBRE_PARQUET"] =fila.get("NOMBRE_PARQUET") or fila["TABLA"]
        fila["ACTIVO"]="S"
        fila["FILTRO"] = fila.get("FILTRO")
        fila["_PARTICION"]= entrada.get("particion") or (cfg.get("particiones") or {}).get(str(fila["TABLA"]))
        filas.append(fila)
    solo_variable = ['.'.join(c) for c in variable if c not in catalogo]
    if inactivas_catalogo:
        logger.info("omitidas por ACTIVO <>'S' en el CATALOGO :%s",",".join(inactivas_catalogo))
    if inactivas_variable:
        logger.info("omitidas por activo <>'S' en el VARIABLE :%s",",".join(inactivas_variable))
    if solo_catalogo:
        logger.warning("en el CATALOGO pero no en la VARIABLE (no se extraen):%s",",".join(solo_catalogo))
    if solo_variable:
        logger.warning("en el VARIABLE pero no en la CATALOGO (no se extraen):%s",",".join(solo_variable))
    if not filas:
        raise SystemExist("Ninguna tabla esta ni en CATALOGO ni en VARIABLE con ESTADO='S'")

    logger.info("%s tabla(s) activas con en el CATALOGO y en VARIABLES a la vez", len(filas))
    sin_particion = [f["TABLA"] for f in filas if not f.get("_PARTICION")]
    if sin_particion:
        logger.warning("%s".join(sin_particion))
    return filtrar_por_procesos(filas, cfg, tipo_ejecucion)



def abrir_log(conn_ctl, cfg: dict, fila: dict, batch_id: str, fecha_proceso) -> int:
    ejecutar(conn_ctl,
             f"INSERT INTO {cfg['tb_proceso_parquet']} "
             f"(nom_proceso, batch_id, esquema, tabla_origen, fecha_proceso, "
             f" archivo_parquet, fec_inicio, estado, host_name) "
             f"VALUES (?, ?, ?, ?, ?, ?, SYSDATETIME(), ?, ?)",
             (cfg["nom_proceso"], batch_id, str(fila["ESQUEMA"]), str(fila["TABLA"]),
              str(fecha_proceso), None, cfg["estado_ejecutando"],
              os.environ.get("HOSTNAME", "spark")))
    filas = filas_de(conn_ctl,
                     f"SELECT MAX(id_log) AS ID FROM {cfg['tb_proceso_parquet']} "
                     f"WHERE batch_id = '{batch_id}' "
                     f"  AND tabla_origen = '{fila['TABLA']}'")
    return int(filas[0]["ID"])


def cerrar_log(conn_ctl, cfg: dict, id_log: int, estado: str,
               archivo: str | None = None, filas: int | None = None,
               segundos: float | None = None, error: str | None = None) -> None:
    try:
        ejecutar(conn_ctl,
                 f"UPDATE {cfg['tb_proceso_parquet']} SET "
                 f"  estado = ?, fec_termino = SYSDATETIME(), "
                 f"  archivo_parquet = COALESCE(?, archivo_parquet), "
                 f"  filas_procesadas = COALESCE(?, filas_procesadas), "
                 f"  duracion_segundos = ?, msg_error = ? "
                 f"WHERE id_log = ?",
                 (estado, archivo, filas, segundos,
                  (error or "")[:int(cfg["error_size_limit"])] or None, id_log))
    except Exception as exc:                                   # noqa: BLE001
        logger.error("no se pudo cerrar la fila %s de la bitacora: %s", id_log, exc)


# ============================================================================
# MAIN
# ============================================================================
def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--jdbc-url", required=True, help="URL de Bantotal (origen)")
    p.add_argument("--driver-class", required=True)
    p.add_argument("--config", required=True, help="JSON materializado por el DAG")
    p.add_argument("--batch-id", required=True)
    p.add_argument("--tipo-ejecucion", default="diario")
    p.add_argument(
        "--proceso", default=None,
        help=("nombre_proceso de UNA sola tabla. Cuando el DAG dibuja una tarea "
              "por proceso, cada tarea envia su propio job con este argumento. "
              "Sin el, se extrae todo el calendario del dia en una sola "
              "aplicacion, que es como corria antes y sigue sirviendo para "
              "lanzar el job a mano."))
    args = p.parse_args()

    with open(args.config, encoding="utf-8") as fh:
        documento = json.load(fh)
    cfg = documento["extraccion"]
    # 'tablas' y 'origen_tablas' son del pipeline entero, no de una mitad: la
    # misma entrada define QUE se extrae y A DONDE se sube, para no tener que
    # agregar una tabla en dos sitios y acordarse de los dos.
    cfg["tablas"] = documento.get("tablas", [])
    cfg["origen_tablas"] = str(documento.get("origen_tablas", "variable")).strip().lower()

    # Credenciales por entorno, nunca por --conf ni por argumento: lo que va en
    # spark.* aparece en la pestana Environment de la interfaz, en ps dentro del
    # contenedor, y -con eventLog activo- queda escrito en disco.
    bt_usuario = os.environ.get("ORIGEN_USUARIO", "")
    bt_clave = os.environ.get("ORIGEN_CLAVE", "")
    ctl_usuario = os.environ.get("DESTINO_USUARIO", "")
    ctl_clave = os.environ.get("DESTINO_CLAVE", "")
    ctl_url = os.environ.get("DESTINO_JDBC_URL", "")
    ctl_clase = os.environ.get("DESTINO_DRIVER_CLASS",
                               "com.microsoft.sqlserver.jdbc.SQLServerDriver")
    if not ctl_url:
        raise SystemExit(
            "Falta DESTINO_JDBC_URL en el entorno. El catalogo y la bitacora "
            "viven en SQL Server, no en Bantotal.")

    spark = (SparkSession.builder
             .appName(f"bt2sql_extraccion_spark {args.batch_id}")
             .config("spark.sql.adaptive.enabled", "true")
             .config("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")
             .getOrCreate())

    conn_ctl = abrir_jdbc(spark, ctl_url, ctl_usuario, ctl_clave, ctl_clase)
    conn_bt = abrir_jdbc(spark, args.jdbc_url, bt_usuario, bt_clave, args.driver_class)

    resultados, con_error = [], []
    try:
        # --- fecha de proceso: del CORE, no del destino ---------------------
        # La toma de Bantotal por la misma razon que el pipeline de pandas: la
        # tabla STG del destino la llena este mismo proceso, asi que leerla de
        # ahi seria preguntarle a la corrida anterior.
        fp = filas_de(conn_bt, cfg["sql_fecha"])
        if not fp:
            raise SystemExit(f"sql_fecha no devolvio ninguna fila: {cfg['sql_fecha']}")
        crudo = str(list(fp[0].values())[0]).strip().split(".")[0]
        fecha_proceso = (datetime.strptime(crudo, "%Y%m%d").date()
                         if crudo.isdigit() and len(crudo) == 8
                         else datetime.fromisoformat(crudo[:10]).date())
        logger.info("fecha de proceso del core: %s", fecha_proceso)

        catalogo = catalogo_de_tablas(cfg, conn_ctl, args.tipo_ejecucion)

        # --proceso recorta DESPUES del calendario, no antes: asi una tarea de
        # un proceso que hoy no entra no lo extrae por la puerta de atras. El
        # DAG ya marca esa tarea como saltada, pero el job no puede confiar en
        # eso -se le puede invocar a mano- y el calendario tiene que valer
        # igual por los dos caminos.
        if args.proceso:
            pedido = args.proceso.strip().upper()
            catalogo = [f for f in catalogo
                        if str(f.get("NOMBRE_PARQUET") or f["TABLA"]).strip().upper() == pedido]
            if not catalogo:
                raise SystemExit(
                    f"El proceso {args.proceso!r} no esta entre los que entran "
                    f"en una corrida {args.tipo_ejecucion!r}.\n"
                    f"O no esta declarado en 'tablas', o su entrada en "
                    f"'procesos' tiene estado=0 o el flag del dia en 0.")
            logger.info("Corrida de UN SOLO proceso: %s", args.proceso)
        carpeta_dia = f"{cfg['output_dir']}/{fecha_proceso:%Y%m%d}"

        # enumerate y no un bucle simple: con una tabla el contador no hace
        # falta, pero con veinte -y con tablas que tardan minutos- el log sin
        # "[7/20]" obliga a contar lineas hacia atras para saber por donde va.
        total_tablas = len(catalogo)
        for n_tabla, fila in enumerate(catalogo, 1):
            tabla = str(fila["TABLA"])
            inicio = datetime.now()
            id_log = abrir_log(conn_ctl, cfg, fila, args.batch_id, fecha_proceso)
            destino = f"{carpeta_dia}/{tabla}"

            # LA CABECERA DE CADA TABLA
            #
            # Antes de este bloque el log solo decia que tabla se habia
            # extraido DESPUES de terminarla. Con las tablas de Bantotal, de 5
            # filas, da igual. Con una tabla de millones de filas son minutos
            # de silencio en los que no se sabe en que esta el job: si se
            # quedo colgado abriendo la conexion, si esta leyendo, o si esta
            # escribiendo. Y si falla, el ERROR salia sin que nada antes
            # dijera a que tabla pertenece.
            #
            # El id_log va aqui a proposito: es la llave para buscar esta
            # misma tabla en ctl_proceso_parquet mientras el job sigue
            # corriendo, sin esperar a que acabe.
            logger.info("=" * 72)
            logger.info("EXTRAYENDO [%s/%s]  %s.%s", n_tabla, total_tablas,
                        fila.get("ESQUEMA", "?"), tabla)
            logger.info("   destino parquet : %s", destino)
            logger.info("   destino STG     : %s",
                        fila.get("TABLA_DESTINO") or "(sin declarar)")
            logger.info("   id_log          : %s   batch: %s", id_log, args.batch_id)
            try:
                df = leer_origen(spark, args.jdbc_url, args.driver_class,
                                 bt_usuario, bt_clave, fila,
                                 fila.get("_PARTICION"), cfg.get("fetchsize", 10000),
                                 fecha_proceso, args.batch_id)

                # Orden de preferencia de los tipos: Variable > tabla destino
                # > lo que infiera el driver. Ver tipos_de_destino().
                mapa_tipos = parsear_tipos(fila.get("TIPOS"), tabla)
                if mapa_tipos:
                    logger.info("[%s] tipos declarados en la Variable: %s columna(s)",
                                tabla, len(mapa_tipos))
                elif str(cfg.get("tipos_desde_destino", True)).lower() not in ("false", "0", "no"):
                    mapa_tipos = tipos_de_destino(conn_ctl, fila.get("TABLA_DESTINO", ""), tabla)
                if not mapa_tipos:
                    logger.warning(
                        "[%s] sin tipos declarados ni deducibles: el parquet "
                        "queda con lo que infiera el driver JDBC. Si la carga "
                        "falla por tipos, declare 'tipos' para esta tabla en la "
                        "Variable.", tabla)
                df = aplicar_tipos(df, mapa_tipos, tabla)

                # Las dos columnas propias, con el MISMO criterio que el
                # pipeline de pandas: FECHA_PROCESO primera, BATCH_ID ultima.
                # Sin esto los dos parquet no son comparables columna a columna.
                df = (df.withColumn("FECHA_PROCESO", F.lit(str(fecha_proceso)).cast(T.DateType()))
                        .withColumn("BATCH_ID", F.lit(args.batch_id)))
                orden = ["FECHA_PROCESO"] + [c for c in df.columns
                                             if c not in ("FECHA_PROCESO", "BATCH_ID")] + ["BATCH_ID"]
                df = df.select(*orden)

                n = df.count()
                if n == 0:
                    cerrar_log(conn_ctl, cfg, id_log, cfg["estado_sin_datos"],
                               filas=0, segundos=(datetime.now() - inicio).total_seconds())
                    logger.info("[%s] sin filas: no se escribe parquet", tabla)
                    resultados.append({"tabla": tabla, "filas": 0, "estado": "SIN_DATOS"})
                    continue

                # Separar el tiempo de LEER del de ESCRIBIR.
                #
                # El df.count() de arriba es lo que fuerza la lectura entera
                # del origen: hasta esa linea Spark no ha traido nada. Asi que
                # el tiempo hasta aqui es LEER y el de la escritura de abajo es
                # ESCRIBIR. Con una sola linea al final los dos quedaban
                # sumados, y son dos tramos que se afinan con palancas
                # distintas: la lectura con 'particion', la escritura con
                # 'archivos_por_tabla'.
                archivos = int(cfg.get("archivos_por_tabla", 1))
                leido_en = (datetime.now() - inicio).total_seconds()
                logger.info("   leidas %s fila(s) en %.1f s; escribiendo "
                            "parquet en %s archivo(s)...",
                            f"{n:,}", leido_en, archivos)
                if archivos == 1 and n > 1000000:
                    logger.warning(
                        "   archivos_por_tabla=1 con %s filas: el coalesce(1) "
                        "deja TODA la escritura en una sola tarea de Spark, en "
                        "un core. Subir executors no acelera este tramo; hay "
                        "que subir archivos_por_tabla en la Variable.",
                        f"{n:,}")

                (df.coalesce(archivos)
                   .write.mode("overwrite")
                   .parquet(destino))

                segundos = (datetime.now() - inicio).total_seconds()
                cerrar_log(conn_ctl, cfg, id_log, cfg["estado_terminado"],
                           archivo=destino, filas=n, segundos=segundos)
                logger.info("EXTRAIDA   [%s/%s]  %s  ->  %s",
                            n_tabla, total_tablas, tabla, destino)
                logger.info("   %s fila(s)  |  leer %.1f s  +  escribir %.1f s  "
                            "=  %.1f s  |  %s fila/s",
                            f"{n:,}", leido_en, segundos - leido_en, segundos,
                            f"{int(n / segundos):,}" if segundos > 0 else "-")
                resultados.append({"tabla": tabla, "filas": n, "estado": "TERMINADO"})

            except Exception as exc:                            # noqa: BLE001
                segundos = (datetime.now() - inicio).total_seconds()
                cerrar_log(conn_ctl, cfg, id_log, cfg["estado_error"],
                           segundos=segundos, error=str(exc))
                logger.error("FALLO      [%s/%s]  %s.%s  ->  %s  (%.1f s)",
                             n_tabla, total_tablas, fila.get("ESQUEMA", "?"),
                             tabla, fila.get("TABLA_DESTINO") or "(sin declarar)",
                             segundos)
                logger.error("   %s", exc)
                con_error.append(tabla)
                resultados.append({"tabla": tabla, "filas": 0, "estado": "ERROR"})
    finally:
        try:
            conn_bt.close()
            conn_ctl.close()
        except Exception:                                       # noqa: BLE001
            pass
        spark.stop()

    total = sum(r["filas"] for r in resultados)
    logger.info("batch %s: %s tabla(s), %s filas, %s con error",
                args.batch_id, len(resultados), f"{total:,}", len(con_error))

    if con_error:
        logger.error("tablas con error: %s", ", ".join(con_error))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
