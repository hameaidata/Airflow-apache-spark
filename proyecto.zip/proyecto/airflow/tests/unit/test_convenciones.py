"""
Hace cumplir las convenciones de docs/CONVENCIONES.md.

COMO FUNCIONA LA LISTA DE EXCEPCIONES

Los DAGs que ya existian cuando se escribio la convencion estan en LEGADO, con
la fecha en que se agregaron. Esa lista esta para ENCOGERSE: cada vez que se
migra un DAG, se quita de ahi. Lo que no se admite es que crezca, y hay un test
que lo comprueba.

La alternativa -escribir tests que fallen desde el primer dia- termina con todo
el mundo ignorando la suite, que es peor que no tenerla.

Ejecucion:
    docker compose exec airflow-scheduler pytest /opt/airflow/tests/unit/test_convenciones.py -v
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest

from raiz_repo import DIR_AIRFLOW  # noqa: E402


RAIZ = Path(__file__).resolve().parents[3]
DIR_RAIZ_DAGS = DIR_AIRFLOW / "dags"
DIR_DAGS = DIR_RAIZ_DAGS / "production"

# ============================================================================
# LISTA DE EXCEPCIONES
# ----------------------------------------------------------------------------
# VACIA desde el 2026-10-07. Los ocho dag_id siguen la convencion y los ocho
# archivos se llaman dag_<dag_id en minusculas>.py.
#
# Historia, para que no se repita: la lista nacio con siete entradas el
# 2026-09-30. Cinco salieron ese mismo dia y NO por haberse renombrado
# -Extraer_datos_bt, carga_parquet_singlestore, VALIDAR_CONEXIONES,
# ODS_PROCESOS_DATAHUB y BDS_PROCESOS_DATAHUB venian de examples/ y templates/,
# que entraron en .airflowignore: dejaron de ser DAGs de nadie-. Las seis que
# quedaban se renombraron de verdad el 2026-10-07:
#
#     etl_bt_parquet_singlestore  ->  STG_BT_PARQUET
#     BT_DATAHUB                  ->  BDS_DATAHUB_PROCESOS
#     S2SQL_EXPORT                ->  EXP_S2SQL_CARGA
#     orquestador_json            ->  UTIL_ORQUESTADOR_JSON
#     auditoria_roles             ->  UTIL_AUDITORIA_ROLES
#     bt_odbc_test                ->  LAB_BT_ODBC
#
# Que la lista este vacia es el estado deseado, no una casualidad: agregar una
# entrada aqui es declarar deuda por escrito, y el test de abajo pone tope.
# ============================================================================
LEGADO_NOMBRE: set[str] = set()

# Archivos que todavia no declaran su cadencia con etiquetas.
LEGADO_CADENCIA: set[str] = set()

# Scripts sueltos que hay que sacar de dags/production/. Ver el test que los
# vigila al final de este archivo: no son una excepcion tolerada, son deuda
# con fecha.
SCRIPTS_A_MOVER = {
    "test_bt_dev.py",
    "test_bt_preproduccion.py",
    "test_sqlserver.py",
}

CAPAS = ("STG", "ODS", "BDS", "CU", "EXP", "UTIL", "LAB")
CADENCIAS = {"continuo", "manual", "disparado"}

PESADOS = ("jaydebeapi", "jpype", "pyodbc", "pyarrow", "singlestoredb")


def patrones_ignorados() -> list[re.Pattern]:
    """Los patrones de .airflowignore, ya compilados.

    Son expresiones regulares -no comodines de shell- y se evaluan contra la
    ruta relativa a airflow/dags/. Asi las interpreta Airflow, y asi hay que
    interpretarlas aqui: si el test mira archivos que el scheduler no parsea,
    reporta problemas que no existen; si mira menos, calla los que si.
    """
    archivo = DIR_RAIZ_DAGS / ".airflowignore"
    if not archivo.exists():
        return []
    patrones = []
    for linea in archivo.read_text(encoding="utf-8").splitlines():
        linea = linea.strip()
        if linea and not linea.startswith("#"):
            patrones.append(re.compile(linea))
    return patrones


def archivos_de_dag() -> list[Path]:
    """Exactamente lo que el DagBag parsea: todo airflow/dags/ de forma
    recursiva, menos lo que .airflowignore excluye, y de eso solo lo que
    define al menos un DAG.

    ANTES ESTE ALCANCE ESTABA MAL: recorria unicamente production/*.py. Con
    eso, examples/ y templates/ -que el scheduler SI importaba- quedaban fuera
    del test, y sus cuatro DAGs registrados no los veia nadie. El test pasaba
    por no mirar.
    """
    ignorados = patrones_ignorados()
    salida = []
    for p in sorted(DIR_RAIZ_DAGS.rglob("*.py")):
        relativa = p.relative_to(DIR_RAIZ_DAGS).as_posix()
        if any(patron.search(relativa) for patron in ignorados):
            continue
        if "DAG(" in p.read_text(encoding="utf-8", errors="replace"):
            salida.append(p)
    return salida


def dag_ids_de(texto: str) -> list[str]:
    """Los dag_id del archivo, resolviendo la forma dag_id=CONSTANTE.

    dag_bds_datahub_procesos.py y dag_exp_s2sql_carga.py no escriben el nombre dentro de
    DAG(): lo declaran arriba como DAG_ID = "..." y lo pasan por variable.
    Buscando solo dag_id="..." esos dos DAGs eran invisibles para todos los
    tests de nombre -que es justo donde un nombre mal puesto se esconde-.
    """
    ids = re.findall(r'dag_id\s*=\s*"([^"]+)"', texto)
    constantes = dict(re.findall(r'^([A-Z_][A-Z0-9_]*)\s*=\s*"([^"]+)"', texto, re.M))
    for variable in re.findall(r'dag_id\s*=\s*([A-Z_][A-Z0-9_]*)\s*,', texto):
        if variable in constantes:
            ids.append(constantes[variable])
    return ids


def bloque_dag(texto: str) -> str:
    """Desde 'with DAG(' hasta el 'as dag:'. Basta para leer sus argumentos."""
    m = re.search(r"with DAG\((.*?)\)\s*as\s+\w+\s*:", texto, re.S)
    return m.group(1) if m else ""


# ============================================================================
# NOMBRES
# ============================================================================
def test_los_dag_id_nuevos_siguen_la_convencion():
    """<CAPA>_<PIPELINE>_<ACCION>, todo en mayusculas.

    La capa va primero porque es lo que agrupa en la lista ordenada de la
    interfaz: los STG_ juntos, los ODS_ juntos, y las utilidades al final sin
    mezclarse con produccion.
    """
    patron = re.compile(rf"^({'|'.join(CAPAS)})_[A-Z0-9]+(_[A-Z0-9]+)*$")
    malos = []
    for archivo in archivos_de_dag():
        for dag_id in dag_ids_de(archivo.read_text(encoding="utf-8")):
            if dag_id in LEGADO_NOMBRE:
                continue
            if not patron.match(dag_id):
                malos.append(f"{dag_id}  ({archivo.name})")
    assert not malos, (
        "estos dag_id no siguen <CAPA>_<PIPELINE>_<ACCION>:\n  " + "\n  ".join(malos)
        + f"\nCapas validas: {', '.join(CAPAS)}"
    )


def test_la_lista_de_legado_no_crece():
    """Si este test falla es porque alguien agrego un dag_id a LEGADO_NOMBRE en
    vez de arreglarlo. La lista esta para encoger."""
    actuales = set()
    for archivo in archivos_de_dag():
        actuales |= set(dag_ids_de(archivo.read_text(encoding="utf-8")))

    sobran = LEGADO_NOMBRE - actuales
    assert not sobran, (
        f"estos dag_id estan en LEGADO_NOMBRE pero ya no existen: {sorted(sobran)}.\n"
        f"Quitelos de la lista: ya estan migrados."
    )
    assert len(LEGADO_NOMBRE) == 0, (
        f"LEGADO_NOMBRE tiene {len(LEGADO_NOMBRE)} entrada(s) y desde el "
        f"2026-10-07 el tope es CERO: los ocho DAGs siguen la convencion.\n"
        f"Un dag_id nuevo que no la siga se arregla antes de entrar, no se "
        f"anota aqui. Si de verdad hace falta una excepcion, suba el tope en "
        f"el mismo commit y explique por que: asi queda en el historial."
    )


def test_el_archivo_se_llama_como_el_dag():
    """dag_<dag_id en minusculas>.py.

    Cuando la interfaz muestra un DAG roto, uno quiere saber que archivo abrir
    sin buscar.
    """
    malos = []
    for archivo in archivos_de_dag():
        ids = dag_ids_de(archivo.read_text(encoding="utf-8"))
        if len(ids) != 1:
            continue
        if ids[0] in LEGADO_NOMBRE:
            continue
        esperado = f"dag_{ids[0].lower()}.py"
        if archivo.name != esperado:
            malos.append(f"{archivo.name} define {ids[0]}, deberia llamarse {esperado}")
    assert not malos, "\n  " + "\n  ".join(malos)


def test_un_dag_por_archivo():
    """Dos DAGs en un archivo significa que un error de sintaxis los rompe los
    dos, y que la interfaz no dice cual archivo abrir."""
    malos = [f"{a.name}: {ids}" for a in archivos_de_dag()
             if len(ids := dag_ids_de(a.read_text(encoding="utf-8"))) > 1]
    assert not malos, "archivos con mas de un DAG:\n  " + "\n  ".join(malos)


# ============================================================================
# CADENCIA: LO QUE DISTINGUE UN PROCESO CONTINUO
# ============================================================================
def test_todo_dag_declara_su_cadencia():
    """Hoy 7 de 8 tienen schedule=None y nada dice si es deliberado.

    Con la etiqueta, un schedule=None deja de ser ambiguo: o lleva 'manual' o
    lleva 'disparado'. Si no lleva ninguna, es un olvido.
    """
    malos = []
    for archivo in archivos_de_dag():
        if archivo.name in LEGADO_CADENCIA or archivo.name in SCRIPTS_A_MOVER:
            continue
        texto = archivo.read_text(encoding="utf-8")
        for m in re.finditer(r'tags\s*=\s*\[([^\]]*)\]', texto):
            etiquetas = set(re.findall(r'"([^"]+)"', m.group(1)))
            if not (etiquetas & CADENCIAS):
                malos.append(f"{archivo.name}: tags={sorted(etiquetas)}")
    assert not malos, (
        "estos DAGs no declaran cadencia:\n  " + "\n  ".join(malos)
        + f"\nAgregue una de: {sorted(CADENCIAS)}"
    )


def test_un_dag_continuo_tiene_horario_de_verdad():
    """Etiquetarlo 'continuo' y dejarlo con schedule=None es peor que no
    etiquetarlo: promete algo que no ocurre."""
    malos = []
    for archivo in archivos_de_dag():
        texto = archivo.read_text(encoding="utf-8")
        bloque = bloque_dag(texto)
        if '"continuo"' in bloque and re.search(r"schedule\s*=\s*None", bloque):
            malos.append(archivo.name)
    assert not malos, (
        "etiquetados 'continuo' pero con schedule=None:\n  " + "\n  ".join(malos)
    )


# ============================================================================
# IMPLEMENTACION
# ============================================================================
def test_toda_tarea_tiene_execution_timeout():
    """Sin el, una consulta trabada deja la tarea en running para siempre y,
    con max_active_runs=1, el DAG entero parado."""
    malos = []
    for archivo in archivos_de_dag():
        if archivo.name in SCRIPTS_A_MOVER:
            continue
        texto = archivo.read_text(encoding="utf-8")

        # Un execution_timeout en default_args lo hereda CADA tarea del DAG.
        # Contarlo como una sola cobertura era el error que hacia fallar a
        # dag_util_auditoria_roles.py y dag_util_orquestador_json.py, que si estaban protegidos.
        bloque = re.search(r"default_args\s*=\s*\{(.*?)\n\}", texto, re.S)
        if bloque and "execution_timeout" in bloque.group(1):
            continue

        tareas = len(re.findall(r"task_id\s*=", texto))
        # EmptyOperator no ejecuta nada: existe para dibujar dependencias y
        # termina en el mismo instante en que arranca. Exigirle un plazo es
        # ruido, y ruido es como una suite deja de leerse.
        vacias = len(re.findall(r"EmptyOperator\(\s*task_id\s*=", texto))
        tareas -= vacias

        plazos = len(re.findall(r"execution_timeout\s*=", texto))
        if tareas > 0 and plazos < tareas:
            malos.append(
                f"{archivo.name}: {tareas} tareas con trabajo real "
                f"({vacias} EmptyOperator aparte), {plazos} con execution_timeout"
            )
    assert not malos, "\n  " + "\n  ".join(malos)


def test_todo_dag_tiene_dagrun_timeout():
    """Con max_active_runs=1, una corrida atascada bloquea TODAS las
    siguientes. execution_timeout protege cada tarea pero no el tiempo en
    queued ni en up_for_retry."""
    malos = [a.name for a in archivos_de_dag()
             if a.name not in SCRIPTS_A_MOVER
             and "dagrun_timeout" not in a.read_text(encoding="utf-8")]
    assert not malos, "sin dagrun_timeout:\n  " + "\n  ".join(malos)


def test_ningun_dag_importa_nada_pesado_al_parsearse():
    """El scheduler importa cada archivo cada 30 segundos. jaydebeapi arrastra
    JPype, que levanta una JVM en cada pasada.

    Y el efecto lateral importa mas: con el import DENTRO de la funcion, un
    driver que falte en un worker hace fallar esa tarea con su traza. Con el
    import arriba, tumba el archivo entero con un Broken DAG y desaparecen
    todos sus DAGs de la interfaz.
    """
    malos = []
    for archivo in archivos_de_dag():
        if archivo.name in SCRIPTS_A_MOVER:
            continue
        try:
            arbol = ast.parse(archivo.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for nodo in arbol.body:            # solo el nivel de modulo
            if isinstance(nodo, (ast.Import, ast.ImportFrom)):
                nombre = (nodo.module or "") if isinstance(nodo, ast.ImportFrom) \
                         else ",".join(a.name for a in nodo.names)
                for pesado in PESADOS:
                    if pesado in nombre:
                        malos.append(f"{archivo.name}:{nodo.lineno} importa {pesado}")
    assert not malos, (
        "imports pesados a nivel de modulo:\n  " + "\n  ".join(malos)
        + "\nMuevalos DENTRO de la funcion que los usa."
    )


@pytest.mark.parametrize("obligatorio", ["catchup", "tags", "description"])
def test_argumentos_obligatorios_del_dag(obligatorio):
    malos = [a.name for a in archivos_de_dag()
             if a.name not in SCRIPTS_A_MOVER
             and obligatorio not in bloque_dag(a.read_text(encoding="utf-8"))]
    assert not malos, f"sin {obligatorio}=:\n  " + "\n  ".join(malos)


def test_start_date_es_fijo():
    """Con datetime.now() el DAG cambia de fecha de inicio en cada parseo y el
    scheduler se comporta de forma impredecible."""
    malos = []
    for archivo in archivos_de_dag():
        bloque = bloque_dag(archivo.read_text(encoding="utf-8"))
        if re.search(r"start_date\s*=\s*(datetime\.now|days_ago|pendulum\.now)", bloque):
            malos.append(archivo.name)
    assert not malos, "start_date dinamico:\n  " + "\n  ".join(malos)


# ============================================================================
# CREDENCIALES
# ============================================================================
def test_ningun_dag_tiene_credenciales_en_texto_plano():
    """Un archivo versionado con la clave del core es una fuga permanente:
    queda en el historial de git aunque se borre despues."""
    patron = re.compile(r'^\s*(PASSWORD|PWD|CLAVE|PASS)\s*=\s*["\'][^"\']{3,}["\']',
                        re.M | re.I)
    malos = []
    for archivo in sorted(DIR_DAGS.rglob("*.py")):
        if patron.search(archivo.read_text(encoding="utf-8", errors="replace")):
            malos.append(archivo.name)

    pendientes = sorted(set(malos) - SCRIPTS_A_MOVER)
    assert not pendientes, (
        "credenciales en texto plano:\n  " + "\n  ".join(pendientes)
        + "\nUse una Connection de Airflow."
    )


def test_los_scripts_con_credenciales_estan_ignorados_por_el_scheduler():
    """Mientras sigan en dags/production/, el scheduler los IMPORTA cada 30
    segundos: abre sesiones de Spark y conexiones al core, con las credenciales
    que llevan dentro.

    Lo correcto es sacarlos de ahi. Mientras tanto, como minimo, que el
    scheduler no los ejecute.
    """
    presentes = {p.name for p in DIR_DAGS.glob("*.py")} & SCRIPTS_A_MOVER
    if not presentes:
        return  # ya se movieron: perfecto

    # Los patrones de .airflowignore son expresiones regulares. Buscar el
    # nombre del archivo como subcadena daba un falso positivo con
    # "production/test_.*\.py", que si los cubre a los tres.
    ignorados = patrones_ignorados()
    sin_ignorar = [n for n in sorted(presentes)
                   if not any(patron.search(f"production/{n}") for patron in ignorados)]
    assert not sin_ignorar, (
        f"estos scripts tienen credenciales, siguen en dags/production/ y el "
        f"scheduler los ejecuta cada 30 segundos: {sin_ignorar}\n"
        f"Muevalos fuera de dags/, o agreguelos a .airflowignore mientras tanto. "
        f"Y rote esas contrasenas."
    )


# ============================================================================
# CONNECTIONS
# ============================================================================
def test_las_conexiones_nuevas_declaran_quien_las_abre():
    """AF_ si la abre el worker de Airflow, SPK_ si la consume un job de Spark.

    No es burocracia: las credenciales que viajan a Spark pueden acabar en la
    pestana Environment de su interfaz y en los event logs, que con
    spark.eventLog.enabled se escriben en disco y sobreviven al job.
    """
    conocidas_legado = {
        "CONEXION_BANTOTAL", "CONEXION_SQLSERVER", "CONEXION_SINGLESTORE",
        "BT_CONEXION_PREPRODUCTION", "BT_PREPRODUCTION",
        "conexion_bitacora", "mi_base", "spark_default",
    }
    patron = re.compile(r'conn_id[^=]*=\s*"([^"]+)"')
    malas = set()
    for archivo in sorted((DIR_AIRFLOW / "dags").rglob("*.py")):
        for conn in patron.findall(archivo.read_text(encoding="utf-8", errors="replace")):
            if conn in conocidas_legado or conn.startswith(("AF_", "SPK_")):
                continue
            if "{" in conn or conn.isupper() is False and "_" not in conn:
                continue
            malas.add(conn)
    assert not malas, (
        f"estas Connections no dicen quien las abre: {sorted(malas)}\n"
        f"Use AF_<MOTOR>_<AMBIENTE> o SPK_<MOTOR>_<AMBIENTE>."
    )


def test_spark_no_recibe_credenciales_por_configuracion():
    """Meterlas en el diccionario properties de spark.read.jdbc o en un
    --conf las expone en tres sitios que nadie audita: la pestana Environment
    de la interfaz de Spark, la salida de ps dentro de los contenedores, y los
    event logs, que quedan EN DISCO para que los lea el History Server.

    La forma correcta -la que ya usa BsgSparkJdbcOperator- es pasarlas por
    variables de entorno.
    """
    malos = []
    for archivo in sorted((DIR_AIRFLOW).rglob("*.py")):
        if archivo.name in SCRIPTS_A_MOVER:
            continue
        # Los propios tests nombran el patron que persiguen. Sin esta linea,
        # este test se denunciaba a si mismo por la cadena que busca.
        if "tests" in archivo.parts:
            continue
        texto = archivo.read_text(encoding="utf-8", errors="replace")
        if "read.jdbc" not in texto and "write.jdbc" not in texto:
            continue
        if re.search(r'"password"\s*:', texto):
            malos.append(f"{archivo.name}: pasa la clave en el dict de properties")
        if re.search(r'--conf[^\n]*password', texto, re.I):
            malos.append(f"{archivo.name}: pasa la clave por --conf")
    assert not malos, "\n  " + "\n  ".join(malos)


def test_ningun_paquete_de_plugins_tapa_la_biblioteca_estandar():
    """Una carpeta en plugins/ que se llame igual que un modulo estandar es una
    mina.

    Airflow ANADE plugins/ al final de sys.path, asi que en operacion normal
    gana la biblioteca estandar y no pasa nada. La prueba de que es asi es que
    Airflow arranca: si ganara plugins/, airflow/configuration.py moriria en
    'import logging' al primer arranque.

    El problema es cualquier otra cosa que ponga plugins/ al PRINCIPIO de
    sys.path -un script de diagnostico, un test, una herramienta-. Ahi el
    paquete del proyecto gana y el fallo sale lejisimos del motivo:

        AttributeError: module 'logging' has no attribute 'getLogger'

    Paso de verdad el 2026-10-07, con plugins/logging/ y plugins/secrets/
    vacios -un __init__.py de cero bytes cada uno- que nadie importaba. Se
    borraron. Este test existe para que no vuelvan.
    """
    import sys

    carpeta = DIR_AIRFLOW / "plugins"
    estandar = set(sys.stdlib_module_names)
    choques = sorted(
        d.name for d in carpeta.iterdir()
        if d.is_dir() and (d / "__init__.py").exists() and d.name in estandar
    )
    assert not choques, (
        f"estos paquetes de plugins/ se llaman igual que un modulo de la "
        f"biblioteca estandar: {choques}.\n"
        f"Renombrelos (por ejemplo bsg_logging, bsg_secrets): cualquier "
        f"proceso que ponga plugins/ al principio de sys.path importara estos "
        f"en vez del estandar, y el error no mencionara plugins/ por ningun lado."
    )


# ============================================================================
# sys.path: el import de un paquete hermano
# ============================================================================
#
# Airflow pone dags/ en sys.path pero NO dags/production/. Los DAGs que
# importan un paquete que vive a su lado -etl_bt2sql, etl_s2sql- tienen que
# agregar su PROPIA carpeta, y los dos errores posibles se ven igual de bien
# en una revision rapida:
#
#   parents[1] en vez de parents[0]  -> agrega dags/, que ya estaba. La linea
#       parece correcta, no da ningun error, y el DAG sigue fallando con
#       ModuleNotFoundError en su primera tarea.
#   insert(0) en vez de append       -> funciona, hasta el dia que alguien cree
#       un json.py o un logging.py en esa carpeta y se rompa el interprete.
#       En este proyecto ya paso con plugins/logging/.
#
# Los dos estuvieron en dag_stg_bt2sql_carga_spark.py a la vez.
PAQUETES_HERMANOS = ("etl_bt2sql", "etl_s2sql")


def _dags_que_importan_un_hermano():
    for archivo in sorted(DIR_DAGS.glob("dag_*.py")):
        texto = archivo.read_text(encoding="utf-8")
        if any(f"from {p}." in texto or f"import {p}" in texto
               for p in PAQUETES_HERMANOS):
            yield archivo, texto


def test_hay_dags_que_importan_un_paquete_hermano():
    """Si esta lista queda vacia, los dos tests de abajo no prueban nada."""
    encontrados = [a.name for a, _ in _dags_que_importan_un_hermano()]
    assert encontrados, (
        "ningun DAG importa etl_bt2sql ni etl_s2sql; si se reorganizo el "
        "proyecto, estos tests sobran o hay que actualizar PAQUETES_HERMANOS")


def test_el_dag_agrega_su_propia_carpeta_y_no_la_de_arriba():
    """La carpeta que se agrega tiene que ser la que CONTIENE el paquete."""
    malos = []
    for archivo, texto in _dags_que_importan_un_hermano():
        hermanos = [p for p in PAQUETES_HERMANOS
                    if (archivo.parent / p / "__init__.py").is_file()
                    and (f"from {p}." in texto or f"import {p}" in texto)]
        if not hermanos:
            continue

        # Se mira QUE se le pasa a sys.path, no si el texto menciona
        # parents[1] en algun sitio. La primera version de este test buscaba
        # "parents[1]" en todo el archivo, y daba el diagnostico equivocado
        # cuando el bloque faltaba por completo pero parents[1] aparecia en
        # otra funcion: decia "agrega una carpeta de arriba" donde en realidad
        # no agregaba ninguna. Un mensaje de error que apunta al sitio
        # equivocado cuesta mas que no tenerlo.
        agregados = re.findall(r"sys\.path\.(?:append|insert)\(\s*(?:0\s*,\s*)?([^)]+)\)",
                               texto)
        # Las variables se resuelven buscando su asignacion en el archivo.
        resueltos = []
        for arg in agregados:
            arg = arg.strip()
            if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", arg):
                m = re.search(rf"^{re.escape(arg)}\s*=\s*(.+)$", texto, re.M)
                arg = m.group(1).strip() if m else arg
            resueltos.append(arg)

        FORMAS_PROPIAS = ("os.path.dirname(os.path.abspath(__file__))",
                          "Path(__file__).resolve().parent)",
                          "Path(__file__).resolve().parents[0]",
                          "os.path.dirname(__file__)")
        propia = any(any(f in r for f in FORMAS_PROPIAS) for r in resueltos)

        if not propia:
            if not resueltos:
                motivo = "no agrega ninguna carpeta a sys.path"
            else:
                motivo = ("agrega una carpeta que no es la suya: "
                          + "; ".join(resueltos)
                          + ". Tiene que ser la propia (parents[0] / "
                            "os.path.dirname(__file__))")
            malos.append(f"{archivo.name}: importa {', '.join(hermanos)} pero {motivo}")
    assert not malos, (
        "Airflow pone dags/ en sys.path, no dags/production/. Estos DAGs "
        "fallaran con ModuleNotFoundError al ejecutar la tarea -no al "
        "parsear-:\n  " + "\n  ".join(malos))


def test_el_dag_usa_append_y_no_insert_en_sys_path():
    """insert(0) pone la carpeta del DAG por delante de la biblioteca estandar.

    No es teorico: en este proyecto una carpeta vacia plugins/logging/ dejo a
    Airflow sin el modulo logging, con un AttributeError que no mencionaba ni
    la carpeta ni sys.path.
    """
    malos = []
    for archivo in sorted(DIR_DAGS.glob("*.py")):
        for n, linea in enumerate(archivo.read_text(encoding="utf-8").splitlines(), 1):
            if "sys.path.insert" in linea and not linea.strip().startswith("#"):
                malos.append(f"{archivo.name}:{n}  {linea.strip()}")
    assert not malos, (
        "sys.path.insert(0, ...) tapa la biblioteca estandar. Use "
        "sys.path.append:\n  " + "\n  ".join(malos))


# ============================================================================
# jaydebeapi devuelve java.lang.String, no str
# ============================================================================
#
# El puente de jaydebeapi es JPype, y por ahi los nombres de columna de
# cur.description llegan como java.lang.String. Ese objeto NO tiene .upper()
# ni .lower() ni .strip(), asi que
#
#     columnas = [d[0].upper() for d in cur.description]
#
# revienta con
#     AttributeError: 'java.lang.String' object has no attribute 'upper'
#
# y el mensaje no menciona ni JDBC ni JPype. Costo dos tareas del DAG
# descubrirlo: la segunda aparicion esperaba en verificar_parquet, dos pasos
# despues de la que fallo.
#
# La regla del proyecto es envolver en str() todo lo que sale de un cursor.
# El job de Spark queda fuera a proposito: pasa por py4j (spark._jvm), que si
# convierte a str de Python.
METODOS_DE_CADENA = ("upper", "lower", "strip", "lstrip", "rstrip",
                     "replace", "split", "title", "casefold")


def _llama_metodo_de_cadena_sin_str(linea: str) -> str | None:
    """Devuelve el metodo si la linea lo llama sobre algo sin envolver."""
    for metodo in METODOS_DE_CADENA:
        # d[0].upper()  /  col[0].strip()  ->  sospechoso
        # str(d[0]).upper()                ->  correcto
        if re.search(rf"\]\s*\.{metodo}\(", linea) and "str(" not in linea:
            return metodo
    return None


def test_los_nombres_de_columna_de_jaydebeapi_se_envuelven_en_str():
    """Cualquier `cur.description` leido por el lado de Airflow.

    Se buscan las lineas que recorren un .description y llaman un metodo de
    cadena sobre el elemento sin pasar por str().
    """
    malos = []
    for archivo in sorted(DIR_DAGS.rglob("*.py")):
        # singlestoredb devuelve str de Python; esa carpeta no usa jaydebeapi.
        if "etl-datahub" in archivo.parts:
            continue
        for n, linea in enumerate(archivo.read_text(encoding="utf-8").splitlines(), 1):
            if ".description" not in linea or linea.strip().startswith("#"):
                continue
            metodo = _llama_metodo_de_cadena_sin_str(linea)
            if metodo:
                malos.append(f"{archivo.name}:{n}  .{metodo}() sin str()  ->  {linea.strip()}")

    assert not malos, (
        "jaydebeapi devuelve los nombres de columna como java.lang.String, que "
        "no tiene metodos de cadena. Envuelva en str():\n  "
        + "\n  ".join(malos))


def test_el_job_de_spark_no_necesita_la_envoltura():
    """Lo que da sentido a la excepcion de arriba: el job lee las columnas por
    py4j y no por JPype, y ahi si llegan como str de Python.

    Si algun dia el job pasara a usar jaydebeapi, esta comprobacion falla y
    avisa de que la regla empieza a aplicarle.
    """
    job = DIR_AIRFLOW.parent / "spark" / "jobs" / "etl" / "bt2sql_extraccion_spark.py"
    if not job.is_file():
        pytest.skip("el job de Spark no esta en este arbol")

    fuente = job.read_text(encoding="utf-8")
    assert "spark._jvm" in fuente, (
        "el job de Spark ya no abre JDBC por py4j. Si paso a jaydebeapi, los "
        "nombres de columna llegan como java.lang.String y hay que envolverlos "
        "en str() igual que en el DAG.")
    assert "import jaydebeapi" not in fuente
